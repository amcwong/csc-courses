from sklearn.impute import KNNImputer
from utils import *
import numpy as np
import matplotlib.pyplot as plt

def knn_impute_by_user(matrix, valid_data, k):
    """ Fill in the missing values using k-Nearest Neighbors based on
    student similarity. Return the accuracy on valid_data.

    See https://scikit-learn.org/stable/modules/generated/sklearn.
    impute.KNNImputer.html for details.

    :param matrix: 2D sparse matrix
    :param valid_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param k: int
    :return: float
    """
    nbrs = KNNImputer(n_neighbors=k)
    # We use NaN-Euclidean distance measure.
    mat = nbrs.fit_transform(matrix)
    acc = sparse_matrix_evaluate(valid_data, mat)
    print("Validation Accuracy: {}".format(acc))
    return acc


def knn_impute_by_item(matrix, valid_data, k):
    """ Fill in the missing values using k-Nearest Neighbors based on
    question similarity. Return the accuracy on valid_data.

    :param matrix: 2D sparse matrix
    :param valid_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param k: int
    :return: float
    """
    #####################################################################
    # TODO:                                                             #
    # Implement the function as described in the docstring.             #
    #####################################################################
    # To make the questions the rows and users the columns
    matrix_T = matrix.T

    # Same knn impute
    nbrs = KNNImputer(n_neighbors=k)
    imputed_matrix_T = nbrs.fit_transform(matrix_T)

    # Transpose the imputed matrix back to og
    imputed_matrix = imputed_matrix_T.T

    acc = sparse_matrix_evaluate(valid_data, imputed_matrix)
    print(f"Validation Accuracy (Item-based, k={k}): {acc}")
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################
    return acc


def main():
    sparse_matrix = load_train_sparse("../data").toarray()
    val_data = load_valid_csv("../data")
    test_data = load_public_test_csv("../data")

    print("Sparse matrix:")
    print(sparse_matrix)
    print("Shape of sparse matrix:")
    print(sparse_matrix.shape)

    #####################################################################
    # TODO:                                                             #
    # Compute the validation accuracy for each k. Then pick k* with     #
    # the best performance and report the test accuracy with the        #
    # chosen k*.                                                        #
    #####################################################################
    sparse_matrix_item = load_train_sparse("../data").toarray()


    k_values = [1, 6, 11, 16, 21, 26]
    impute_by_user_val_accuracies = []
    impute_by_item_val_accuracies = []

    # Loop over each k value to find the validation accuracy
    for k in k_values:
        # print(f"Running kNN with k={k}")
        # User acc
        acc_user = knn_impute_by_user(sparse_matrix, val_data, k)
        impute_by_user_val_accuracies.append(acc_user)

        # Item acc
        acc_item = knn_impute_by_item(sparse_matrix_item, val_data, k)
        impute_by_item_val_accuracies.append(acc_item)

    # Plot the validation accuracies for user
    plt.plot(k_values, impute_by_user_val_accuracies, marker='o')
    plt.xlabel('k')
    plt.ylabel('Validation Accuracy for user')
    plt.title('Validation Accuracy vs. k')
    plt.show()

    # Plot val acc for item
    plt.plot(k_values, impute_by_item_val_accuracies, marker='o')
    plt.xlabel('k')
    plt.ylabel('Validation Accuracy for item')
    plt.title('Item-Based Validation Accuracy vs. k')
    plt.show()

    # Select the best k for user
    best_k_user = k_values[np.argmax(impute_by_user_val_accuracies)]
    print(f"Best k for user: {best_k_user}")

    # Select the best k for item
    best_k_item = k_values[np.argmax(impute_by_item_val_accuracies)]
    print(f"Best k for item: {best_k_item}")


    # Compute test accuracy using the best k
    best_test_acc_user = knn_impute_by_user(sparse_matrix, test_data, best_k_user)
    print(f"Impute by user. Test Accuracy with k={best_k_user}: {best_test_acc_user}")

    best_test_acc_item = knn_impute_by_user(sparse_matrix, test_data, best_k_item)
    print(f"Impute by item: Test Accuracy with k={best_k_item}: {best_test_acc_item}")

    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################

# I wrote the answers for the written questions in the docstring for the
# following functions
def d():
    '''

    (d) Which one of user-based and item-based collaborative
    filtering is better? Why?

    Answer for question d:
    222
    Imputing by user showed slightly higher test accuracy.
        Impute by user. Test Accuracy with k=11: 0.6841659610499576
        Validation Accuracy: 0.6683601467682755
        Impute by item: Test Accuracy with k=21: 0.6683601467682755)


    However, when comparing the best k values for user and item imputing,
    imputing by item demonstrated a greater validation accuracy.
        Validation Accuracy (Item-based, k=21): 0.6922099915325995
        Validation Accuracy: (User-based, k=11):0.6895286480383855

    The results are not terribly clear cut for this data set.
    However, my answer is that item based collaborative filtering is better
    because I would imagine that the rate of student answering
    questions would increase faster than the rate of item addition.

    For the sake of kNN, each new user/student
    would introduce a new dimension to the
    dataset, this makes the complexity of finding nearest neighbors
    among users more difficult.
    For example, increasing the dimension many times might lead to problems
    with the curse of dimensionality where as the dimensions get larger things
    get further apart.
    Additionally, when a new user is added, we would have to calculate my
    similarity to many users rather than the similarity of the thing I just
    watched to other things. The former seems much more computationally
    intensive as we usually have more people than movies.

    While there are currently more items than users,
    assuming that (eventually) at least more than one student
    will end up answering each question after more data is collected,
    item based collaborative filtering is better.
    '''
    pass


def e():
    '''
    e) List two potential limitations of kNN for the task you are given.

    Answer for question e:
    1. Scalability
    For a problem like this, scalability would be a problem because
    upon each new input, we would have to recalculate the distance between
    that data point and every other data point. So whether it is adding a new
    user or a new question, the cost to calculate the next one increases
    quadratically with respect to how many points we already have.

    2. Insufficient number of neighbors
    Because most of the entries are nan, this means that most questions are not
    answered by each student. The way kNN works is by finding similar entries
    to a particular entry. However, since most of the entries are nan, finding
    a very similar student to a given student is less likely. So, the kNN
    might instead be using only somewhat similar students to compare with each
    other for kNN. Ideally, we compare very similar students to learn the most
    appropriate k values but the ability for the model to learn might be
    hindered if data points are grouped haphazardly.
    (This might pose problems for splitting for k on users in general too).
    '''
    pass

if __name__ == "__main__":
    main()
