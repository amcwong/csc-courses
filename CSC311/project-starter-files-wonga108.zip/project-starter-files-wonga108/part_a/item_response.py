from utils import *
import numpy as np
import matplotlib.pyplot as plt


def sigmoid(x):
    """ Apply sigmoid function.
    """
    return np.exp(x) / (1 + np.exp(x))


def neg_log_likelihood(data, theta, beta):
    """ Compute the negative log-likelihood.

    You may optionally replace the function arguments to receive a matrix.

    :param data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param theta: Vector
    :param beta: Vector
    :return: float
    """
    #####################################################################
    # TODO:                                                             #
    # Implement the function as described in the docstring.             #
    #####################################################################
    num_data_points = len(data["is_correct"])
    log_lklihood = 0.0

    # Iterate over each observation
    for idx in range(num_data_points):
        correct = data["is_correct"][idx]
        student_id = data["user_id"][idx]
        question_id = data["question_id"][idx]

        # Calculate the model's probability of a correct answer
        prob_correct = sigmoid(theta[student_id] - beta[question_id])

        # Compute log-likelihood for this observation
        log_likelihood_contribution = correct * np.log(prob_correct) + \
                                      (1 - correct) * np.log(1 - prob_correct)
        log_lklihood += log_likelihood_contribution

    # log_lklihood = log_lklihood
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################
    return -log_lklihood


def update_theta_beta(data, lr, theta, beta):
    """ Update theta and beta using gradient descent.

    You are using alternating gradient descent. Your update should look:
    for i in iterations ...
        theta <- new_theta
        beta <- new_beta

    You may optionally replace the function arguments to receive a matrix.

    :param data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param lr: float
    :param theta: Vector
    :param beta: Vector
    :return: tuple of vectors
    """
    #####################################################################
    # TODO:                                                             #
    # Implement the function as described in the docstring.             #
    #####################################################################
    # theta: is A vector of the current estimates of
    #   the ability parameters for each student.
    # beta: A vector of the current estimates of the
    #   difficulty parameters for each question.

    # Works assuming numpy vectors
    theta_update = theta.copy()
    beta_update = beta.copy()

    # First pass for theta update
    for k in range(len(data["is_correct"])):
        c = data["is_correct"][k]
        i = data["user_id"][k]
        j = data["question_id"][k]
        theta_update[i] -= lr * (- c + sigmoid(theta[i] - beta[j]))

    # Second pass for beta update, using updated theta values
    for k in range(len(data["is_correct"])):
        c = data["is_correct"][k]
        i = data["user_id"][k]
        j = data["question_id"][k]
        beta_update[j] -= lr * (c - sigmoid(theta_update[i] - beta[j]))

    # Apply updates
    theta, beta = theta_update, beta_update

    return theta, beta
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################
    return theta, beta


def irt(data, val_data, lr, iterations):
    """ Train IRT model.

    You may optionally replace the function arguments to receive a matrix.

    :param data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param val_data: A dictionary {user_id: list, question_id: list,
    is_correct: list}
    :param lr: float
    :param iterations: int
    :return: (theta, beta, val_acc_lst)
    """
    # TODO: Initialize theta and beta.
    theta = np.zeros(542)  # Abilities of each student
    beta = np.zeros(1774)  # Difficulties of each question

    train_lls = []  # List to store training log-likelihoods
    val_lls = []  # List to store validation log-likelihoods
    val_acc_lst = []

    for i in range(iterations):

        train_ll = neg_log_likelihood(data, theta, beta)
        train_lls.append(train_ll)


        val_ll = neg_log_likelihood(val_data, theta, beta)
        val_lls.append(val_ll)


        score = evaluate(val_data, theta, beta)
        val_acc_lst.append(score)

        print(
            f"Iteration {i + 1}: Train LL = {train_ll}, Val LL = {val_ll}, Score = {score}")

        theta, beta = update_theta_beta(data, lr, theta, beta)

    return theta, beta, train_lls, val_lls, val_acc_lst


def evaluate(data, theta, beta):
    """ Evaluate the model given data and return the accuracy.
    :param data: A dictionary {user_id: list, question_id: list,
    is_correct: list}

    :param theta: Vector
    :param beta: Vector
    :return: float
    """
    pred = []
    for i, q in enumerate(data["question_id"]):
        u = data["user_id"][i]
        x = (theta[u] - beta[q]).sum()
        p_a = sigmoid(x)
        pred.append(p_a >= 0.5)
    return np.sum((data["is_correct"] == np.array(pred))) \
           / len(data["is_correct"])


def main():
    train_data = load_train_csv("../data")
    # You may optionally use the sparse matrix.
    sparse_matrix = load_train_sparse("../data")
    val_data = load_valid_csv("../data")
    test_data = load_public_test_csv("../data")

    #####################################################################
    # TODO:                                                             #
    # Tune learning rate and number of iterations. With the implemented #
    # code, report the validation and test accuracy.                    #
    #####################################################################

    # This code below uses the trained best number of iterations and lr
    #
    #####################################################################

    num_iteration = 80
    lr = 0.001

    theta, beta, train_lls, val_lls, val_acc_lst = (
        irt(train_data, val_data, lr, num_iteration))

    # Plot the training and validation log-likelihoods
    plt.figure(figsize=(10, 6))
    plt.plot(train_lls, label='Training Log-Likelihood')
    plt.plot(val_lls, label='Validation Log-Likelihood')
    plt.xlabel('Iteration')
    plt.ylabel('Negative Log-Likelihood')
    plt.title('Training and Validation Log-Likelihoods')
    plt.legend()
    plt.grid(True)
    plt.show()

    # Evaluate final model performance
    val_acc = evaluate(val_data, theta, beta)
    test_acc = evaluate(test_data, theta, beta)
    print("Final Validation Accuracy: ", val_acc)
    print("Final Test Accuracy: ", test_acc)

    # Below Is the code used to tune the hyper parameters for part c
    #####################################################################

    # learning_rates = [0.001, 0.01, 0.1]
    # iteration_counts = [20, 40, 80]
    #
    # best_val_acc = 0
    # best_settings = (0, 0)
    # # best_theta = None
    # # best_beta = None
    #
    # # Search over learning rates and iteration
    # for lr in learning_rates:
    #     for num_iterations in iteration_counts:
    #         theta, beta, val_acc_lst = irt(train_data, val_data, lr,
    #                                        num_iterations)
    #
    #         val_acc = evaluate(val_data, theta, beta)
    #         test_acc = evaluate(test_data, theta, beta)
    #         print(
    #             f"LR: {lr}, Iterations: {num_iterations}, Validation Accuracy: "
    #             f"{val_acc}, Test Accuracy: {test_acc}")
    #
    #         if val_acc > best_val_acc:
    #             best_theta = theta
    #             best_beta = beta
    #             best_val_acc = val_acc
    #             best_settings = (lr, num_iterations)
    #
    # print(f"Best learning rate: {best_settings[0]}, Best num of iterations: "
    #       f"{best_settings[1]}, Best validation accuracy: {best_val_acc},")
    #
    #
    # # Best Learning Rate: 0.001,
    # # Best Number of Iterations: 80,
    # # Best Validation Accuracy: 0.7075924357888794
    # # Best learning rate: 0.001, Best num of iterations: 80,
    #####################################################################


    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################

    #####################################################################
    # TODO:                                                             #
    # Implement part (d)                                                #

    beta_values = np.array([beta[0], beta[1], beta[2]])

    plt.figure(figsize=(10, 6))
    for beta in beta_values:
        probabilities = sigmoid(theta - beta)
        plt.plot(theta, probabilities, 'o',
                 label=f'Question with β={beta:.2f}')

    plt.title('Probability of Correct Response for Different Questions')
    plt.xlabel('Ability (theta)')
    plt.ylabel('Probability of Correct Response')
    plt.legend()
    plt.grid(True)
    plt.show()


    #####################################################################
    pass
    #####################################################################
    #                       END OF YOUR CODE                            #
    #####################################################################


if __name__ == "__main__":
    main()
